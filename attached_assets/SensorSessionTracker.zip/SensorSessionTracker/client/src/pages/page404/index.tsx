import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md mx-4 border-border/70 shadow-md">
        <CardContent className="pt-6 pb-6">
          <div className="flex mb-4 gap-3 items-center">
            <AlertCircle className="h-10 w-10 text-red-500" />
            <h1 className="text-2xl font-bold text-gray-900">404 Page Not Found</h1>
          </div>

          <p className="mt-4 mb-6 text-gray-600">
            The page you are looking for doesn't exist or has been moved.
          </p>
          
          <div className="flex justify-center">
            <Button asChild>
              <Link href="/">Return to Dashboard</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}