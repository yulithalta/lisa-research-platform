SensorSessionTracker - Test ZIP
=========================

Este es un archivo ZIP de prueba para verificar la funcionalidad de creación de archivos ZIP.
Contiene datos de sensores consolidados y archivos de grabación.

Estructura:
- /recordings: Grabaciones de vídeo
- /data: Datos de sensores y dispositivos
