SensorSessionTracker - Test ZIP
=========================

Este es un archivo ZIP de prueba para verificar la funcionalidad de creación de archivos ZIP.
Contiene datos de sensores consolidados y archivos de grabación.

Estructura:
- /recordings: Grabaciones de vídeo
- /data: Datos de sensores y dispositivos
  - zigbee-data.json: Datos completos de sensores en formato JSON
  - zigbee-sensors.csv: Datos de sensores en formato CSV para análisis
  - devices.json: Lista de todos los dispositivos
  - session_metadata.json: Metadatos técnicos de la sesión
